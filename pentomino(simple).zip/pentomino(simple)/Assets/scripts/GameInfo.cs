﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameInfo : MonoBehaviour {

    public static int index = 0;
    public GameObject nextLevelMenu;
    int nextSceneLoad;


    void Start()
    {
        nextSceneLoad = SceneManager.GetActiveScene().buildIndex + 1;
        nextLevelMenu.SetActive(false);
    }

    void Update()
    {
        if(index == 12)
        {
            nextLevelMenu.SetActive(true);
            index = 0;
            if (nextSceneLoad > PlayerPrefs.GetInt("levelAt"))
            {
                PlayerPrefs.SetInt("levelAt", nextSceneLoad);
                Debug.Log(PlayerPrefs.GetInt("levelAt"));
            }
        }
    }
}
